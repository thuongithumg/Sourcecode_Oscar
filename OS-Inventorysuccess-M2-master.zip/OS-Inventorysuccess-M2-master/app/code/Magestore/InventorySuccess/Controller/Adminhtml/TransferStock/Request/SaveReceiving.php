<?php
/**
 * Copyright © 2016 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magestore\InventorySuccess\Controller\Adminhtml\TransferStock\Request;


class SaveReceiving extends \Magestore\InventorySuccess\Controller\Adminhtml\TransferStock\AbstractRequest
{

    public function execute()
    {

    }

}


