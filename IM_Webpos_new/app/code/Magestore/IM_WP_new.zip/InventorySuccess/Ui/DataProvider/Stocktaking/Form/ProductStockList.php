<?php
/**
 * Copyright © 2016 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magestore\InventorySuccess\Ui\DataProvider\Stocktaking\Form;

/**
 * Class ProductStockList
 * @package Magestore\InventorySuccess\Ui\DataProvider\Stocktaking\Form
 */
class ProductStockList extends \Magestore\InventorySuccess\Ui\DataProvider\Form\Modifier\ProductStockList
{

}