<?php
/**
 * Copyright © 2016 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magestore\InventorySuccess\Ui\Component\Listing\Columns\Product\NoneInWarehouse;


/**
 * Class Columns
 * @package Magestore\InventorySuccess\Ui\Component\Listing\Columns\Product\NoneInWarehouse
 */
class Columns extends \Magestore\InventorySuccess\Ui\Component\Listing\Columns\AbstractColumns
{

}