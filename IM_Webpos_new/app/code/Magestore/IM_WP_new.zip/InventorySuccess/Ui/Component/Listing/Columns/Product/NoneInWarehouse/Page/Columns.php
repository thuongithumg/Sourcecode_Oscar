<?php
/**
 * Copyright © 2016 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magestore\InventorySuccess\Ui\Component\Listing\Columns\Product\NoneInWarehouse\Page;

/**
 *
 */
use Magestore\InventorySuccess\Model\ResourceModel\Product\NoneInWarehouse\CollectionFactory;

/**
 * Class DataProvider
 * @package Magestore\InventorySuccess\Ui\DataProvider\Product\NoneInWarehouse\Page
 */
class Columns extends \Magestore\InventorySuccess\Ui\Component\Listing\Columns\AbstractCatalogColumns
{

}