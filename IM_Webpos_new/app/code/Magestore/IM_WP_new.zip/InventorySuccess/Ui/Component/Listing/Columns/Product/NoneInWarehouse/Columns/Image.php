<?php
/**
 * Copyright © 2016 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magestore\InventorySuccess\Ui\Component\Listing\Columns\Product\NoneInWarehouse\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

/**
 * Class Actions
 * @package Magestore\InventorySuccess\Ui\Component\Listing\Columns\Product\NoneInWarehouse\Columns
 */
class Image extends \Magestore\InventorySuccess\Ui\Component\Listing\Columns\AbstractImageColumn
{

}