<?php

/**
 * Copyright © 2016 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magestore\InventorySuccess\Helper;

    /**
     * Helper Data.
     * @category Magestore
     * @package  Magestore_InventorySuccess
     * @module   Inventorysuccess
     * @author   Magestore Developer
     */
    /**
     * Class Warehouse
     * @package Magestore\InventorySuccess\Helper
     */
/**
 * Class Warehouse
 * @package Magestore\InventorySuccess\Helper
 */
class Warehouse extends \Magento\Framework\App\Helper\AbstractHelper
{


}