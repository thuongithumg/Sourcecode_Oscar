<?php

class Magestore_Barcodesuccess_Model_Service_FilterCollection_Filter
{

    protected $_attribute_code = array(
        'product_sku' => 'sku',
        'status' => 'value',
        'name'=>'value',
        'attribute_set_id' =>'attribute_set_id',
        // 'set_name' => 'set_name',
    );
    static function _barcode_attribute_status(){
        return array(
            "1" => "Enabled",
            "2" => "Disabled");
    }
    public function filterStatus($collection,$columnId,$value){
        $field = $columnId."_table";
        return $collection->getSelect()->where($field.'.value = ?', $value);
    }

    public function filterName($collection,$columnId,$value){
        $field = $columnId."_table";
        return $collection->getSelect()->where($field.'.value like ?', '%'. $value.'%');
    }

    public function filterAttributeSetName($collection,$columnId,$value){
        $field = $columnId."_table";
        return $collection->getSelect()->where('attribute_set_id_table.attribute_set_id = ?', $value);
    }


    /**
     * @param $collection
     * @return mixed
     */
    public function mappingAttribute($collection,$flag = false){
        $main_id = "main_table.product_id";
        if($flag){
            $main_id = "$flag";
        }
        $attributeCode = $this->_attribute_code;
        foreach($attributeCode as $code => $value){
            $alias = $code . '_table';
            $attribute = Mage::getSingleton('eav/config')
                ->getAttribute(Mage_Catalog_Model_Product::ENTITY, $code);
            if(($code == 'name') || ($code == 'status')){
                $collection->getSelect()->join(
                    array($alias => $attribute->getBackendTable()),
                    "$main_id = $alias.entity_id AND $alias.attribute_id={$attribute->getId()} AND $alias.store_id=0",
                    array($code => $value)

                );
//                zend_debug::dump($collection->getData());die();
            }else{
                $collection->getSelect()->join(
                    array($alias => $attribute->getBackendTable()),
                    "$main_id = $alias.entity_id",
                    array($code => $value)
                );
            }

        }
        return $collection;
    }
}