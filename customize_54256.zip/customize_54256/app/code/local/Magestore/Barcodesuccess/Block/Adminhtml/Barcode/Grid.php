<?php
/**
 *
 *  Magestore
 *   NOTICE OF LICENSE
 *
 *   This source file is subject to the Magestore.com license that is
 *   available through the world-wide-web at this URL:
 *   http://www.magestore.com/license-agreement.html
 *
 *   DISCLAIMER
 *
 *   Do not edit or add to this file if you wish to upgrade this extension to newer
 *   version in the future.
 *
 * @category    Magestore
 * @package     Magestore_Barcodesuccess
 * @copyright   Copyright (c) 2016 Magestore (http://www.magestore.com/)
 * @license     http://www.magestore.com/license-agreement.html
 *
 *
 */

/**
 * Barcodesuccess Grid Block
 *
 * @category    Magestore
 * @package     Magestore_Barcodesuccess
 * @author      Magestore Developer
 */
class Magestore_Barcodesuccess_Block_Adminhtml_Barcode_Grid extends
    Mage_Adminhtml_Block_Widget_Grid
{
    /**
     * Magestore_Barcodesuccess_Block_Adminhtml_Barcode_Grid constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->setId('barcodeGrid');
        $this->setDefaultSort(Magestore_Barcodesuccess_Model_Barcode::BARCODE_ID);
        $this->setDefaultDir('ASC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(true);
    }

    /**
     * Retrieve
     *
     * @return string
     */
    protected function _getTierProductTable()
    {
        return $this->getTable('catalog/product');
    }

    /**
     * prepare collection for block to display
     *
     * @return Magestore_Barcodesuccess_Block_Adminhtml_Barcode_Grid
     */
    protected function _prepareCollection()
    {
        // thêm Attribute vào Grid Barcode Listing!
        $collection = Mage::getModel('barcodesuccess/barcode')->getCollection();
        Mage::getSingleton('barcodesuccess/service_filterCollection_filter')->mappingAttribute($collection);
       // zend_debug::dump($collection->getData());die();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    /**
     * prepare columns for this grid
     *
     * @return Magestore_Barcodesuccess_Block_Adminhtml_Barcode_Grid
     */
    protected function _prepareColumns()
    {
        if ( !$this->_isExport ) {
            $this->addColumn('in_barcodelist', array(
                'header_css_class' => 'a-center',
                'width'            => '50px',
                'type'             => 'checkbox',
                'name'             => 'in_barcodelist',
                'align'            => 'center',
                'index'            => Magestore_Barcodesuccess_Model_Barcode::BARCODE_ID,
            ));
            $this->addColumn(Magestore_Barcodesuccess_Model_Barcode::BARCODE_ID, array(
                'header'           => Mage::helper('barcodesuccess')->__(' '),
                'width'            => '50px',
                'align'            => 'right',
                'index'            => Magestore_Barcodesuccess_Model_Barcode::BARCODE_ID,
                'column_css_class' => 'no-display',
                'header_css_class' => 'no-display',
                'type'             => 'input',
            ));
        }
        $this->addColumn('barcode_id_label', array(
            'header' => Mage::helper('barcodesuccess')->__('ID'),
            'width'  => '200px',
            'type'   => 'number',
            'align'  => 'right',
            'index'  => Magestore_Barcodesuccess_Model_Barcode::BARCODE_ID,
        ));

        $this->addColumn('barcode_label', array(
            'header'           => Mage::helper('barcodesuccess')->__('Barcode'),
            'width'            => '200px',
            'align'            => 'left',
            'index'            => Magestore_Barcodesuccess_Model_Barcode::BARCODE,
            'column_css_class' => 'no-display',
            'header_css_class' => 'no-display',
        ));
        if ( !$this->_isExport ) {
            $this->addColumn(Magestore_Barcodesuccess_Model_Barcode::BARCODE, array(
                'header' => Mage::helper('barcodesuccess')->__('Barcode'),
                'width'  => '200px',
                'align'  => 'left',
                'type'   => 'input',
                'index'  => Magestore_Barcodesuccess_Model_Barcode::BARCODE,
            ));
        }

        $this->addColumn('name', array(
            'header' => Mage::helper('barcodesuccess')->__('Name'),
            'width'  => '80px',
            'index'  => 'name',
            'type'   => $this->_isExport ? 'text' : 'input',
            'filter_condition_callback' => array($this, '_filterNameCallback'),
        ));

        $this->addColumn('product_sku', array(
            'header' => Mage::helper('barcodesuccess')->__('Sku'),
            'width'  => '50px',
            'index'  => 'product_sku',
            'type'   => $this->_isExport ? 'text' : 'input',
        ));

        $sets = Mage::getResourceModel('eav/entity_attribute_set_collection')
           ->setEntityTypeFilter(Mage::getModel('catalog/product')->getResource()->getTypeId())
           ->load()
           ->toOptionHash();

       $this->addColumn('set_name',
           array(
               'header'=> Mage::helper('barcodesuccess')->__('Attrib. Set Name'),
               'width' => '20px',
               'index' => 'attribute_set_id',
               'type'  => 'options',
               'options'   => $sets,
               'filter_condition_callback' => array($this, '_filterAttributeSetNameCallback'),

           ));

        $this->addColumn(Magestore_Barcodesuccess_Model_Barcode::SUPPLIER_CODE, array(
            'header' => Mage::helper('barcodesuccess')->__('Supplier'),
            'width'  => '20px',
            'type'   => $this->_isExport ? 'text' : 'input',
            'filter'    => false,
            'index'  => Magestore_Barcodesuccess_Model_Barcode::SUPPLIER_CODE,
        ));

        $this->addColumn(Magestore_Barcodesuccess_Model_Barcode::PURCHASED_TIME, array(
            'header' => Mage::helper('barcodesuccess')->__('Purchased Time'),
            'type'   => 'datetime',
            'width'  => '20px',
            'index'  => Magestore_Barcodesuccess_Model_Barcode::PURCHASED_TIME,
        ));

        $this->addColumn('status', array(
            'header' => Mage::helper('barcodesuccess')->__('Status'),
            'width'  => '20px',
            'index'  => 'status',
            'type'   => 'options',
            'options'   => Magestore_Barcodesuccess_Model_Service_FilterCollection_Filter::_barcode_attribute_status(),
            'filter_condition_callback' => array($this, '_filterStatusCallback'),

        ));

        $this->addColumn('action',
            array(
                'header'    => Mage::helper('barcodesuccess')->__('Detail'),
                'type'      => 'action',
                'width'     => '10px',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption' => Mage::helper('barcodesuccess')->__('View'),
                        'url'     => array('base' => '*/*/view'),
                        'field'   => 'id',
                    ),
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
            ));

        $this->addExportType('*/*/exportCsv', Mage::helper('barcodesuccess')->__('CSV'));
//        $this->addExportType('*/*/exportXml', Mage::helper('barcodesuccess')->__('XML'));

        return parent::_prepareColumns();
    }


    protected function _filterStatusCallback($collection,$column){
        if (!($value = $column->getFilter()->getValue())) {
            return;
        }
        return  Mage::getSingleton('barcodesuccess/service_filterCollection_filter')->filterStatus($collection,$column->getId(),$value);
    }

    protected function _filterNameCallback($collection,$column){
        if (!($value = $column->getFilter()->getValue())) {
            return;
        }
        return  Mage::getSingleton('barcodesuccess/service_filterCollection_filter')->filterName($collection,$column->getId(),$value);
    }

    protected function _filterAttributeSetNameCallback($collection,$column){
        if (!($value = $column->getFilter()->getValue())) {
            return;
        }
        return  Mage::getSingleton('barcodesuccess/service_filterCollection_filter')->filterAttributeSetName($collection,$column->getId(),$value);
    }

    /**
     * prepare mass action for this grid
     *
     * @return Magestore_Barcodesuccess_Block_Adminhtml_Barcode_Grid
     */
    protected function _prepareMassaction()
    {
        return $this;
    }

    /**
     * @param $row
     * @return string
     */
    public function getRowUrl( $row )
    {
        return '';
    }


    /**
     * get grid ajax url
     *
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('*/*/grid', array(
            '_current' => true,
        ));
    }
}