<?php

/**
 * Copyright © 2018 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magestore\Webpos\Model\Checkout;

class TaxClass extends \Magento\Tax\Model\TaxClass\Repository
    implements \Magestore\Webpos\Api\Checkout\TaxClassInterface
{
    
}
