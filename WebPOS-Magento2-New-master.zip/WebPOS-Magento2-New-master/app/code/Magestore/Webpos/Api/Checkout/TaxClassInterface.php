<?php

/**
 * Copyright © 2018 Magestore. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magestore\Webpos\Api\Checkout;

/**
 * Interface TaxClassInterface
 * @package Magestore\Webpos\Api\Checkout
 */
interface TaxClassInterface extends \Magento\Tax\Api\TaxClassRepositoryInterface
{

}
