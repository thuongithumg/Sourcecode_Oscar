<?php
/**
 * Created by Wazza Rooney on 1/11/18 8:33 AM
 * Copyright (c) 2018. All rights reserved.
 * Last modified 7/6/17 10:31 AM
 */

/**
 * Interface Magestore_WebposReturnproduct_Api_ReturnProductInterface
 */
interface Magestore_WebposReturnproduct_Api_ReturnProductInterface
{
    const ACTION_REFUND = 'return_product';
    const REFUND_ITEMS_KEY = 'items';
    const LOCATION_ID_KEY = 'location_id';

    /**
     * @return Magestore_WebposReturnproduct_Api_ReturnProductInterface
     */
    public function refund();
}
