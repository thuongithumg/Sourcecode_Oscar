<?php

/*
 * Web POS by Magestore.com
 * Version 2.3
 * Updated by Daniel - 12/2015
 */
$installer = $this;

$installer->startSetup();

$installer->endSetup();

        
