<?php
/**
 * Created by Wazza Rooney on 1/11/18 8:31 AM
 * Copyright (c) 2018. All rights reserved.
 * Last modified 9/27/17 5:25 PM
 */

class Magestore_Webpos_Model_Api2_ReturnProduct_Rest_Admin_V1 extends Magestore_Webpos_Model_Api2_Abstract
    implements Magestore_Webpos_Api_ReturnProductInterface
{

    /**
     * Magestore_Webpos_Model_Api2_ReturnProduct_Rest_Admin_V1 constructor.
     */
    public function __construct() {
//        $this->_service = $this->_createService('checkout_shoppingCart');
        $this->_helper = Mage::helper('inventorywarehouse/warehouse');
    }

    /**
     * Dispatch actions
     */
    public function dispatch()
    {
        $this->_initStore();
        switch ($this->getActionType()) {
            case self::ACTION_REFUND:
                $this->_render($this->refund());
                $this->getResponse()->setHttpResponseCode(Mage_Api2_Model_Server::HTTP_OK);
                break;
        }
    }

    public function refund()
    {
        $response = array(
            'error' => false,
            'message' => '',
            'items' => array(),
        );
        $items = $this->_processRequestParams(self::REFUND_ITEMS_KEY);
        $locationId = $this->_processRequestParams(self::LOCATION_ID_KEY);

        if ($this->isEnable('Magestore_InventorySuccess')) {
            $mapCollection = Mage::getModel('inventorysuccess/warehouseLocationMap')->getCollection()
                ->addFieldToFilter('location_id', array('eq' => $locationId));
            $currentWarehouseId = $mapCollection->getSize() && $mapCollection->getFirstItem()->getData('warehouse_id') ? : 2;

            foreach ($items as $item) {
                $warehouseData = array();
                /** @var Mage_Catalog_Model_Product $product */
                $product = Mage::getModel('catalog/product')->load($item['id']);

                $stockRegistryService = Magestore_Coresuccess_Model_Service::stockRegistryService();
                $stocks = $stockRegistryService->getStocksByProduct($product->getId());

                foreach($stocks as $stockData) {
                    if (!$stockData[ Magestore_Inventorysuccess_Model_Warehouse_Product::WAREHOUSE_ID ]) {
                        continue;
                    }

                    $stockItemWarehouseId = $stockData[ Magestore_Inventorysuccess_Model_Warehouse_Product::WAREHOUSE_ID ];

                    $saveData = array(
                        'warehouse'      => $stockItemWarehouseId . '',
                        'warehouse_id'   => $stockItemWarehouseId,
                        'total_qty'      =>
                            $stockItemWarehouseId == $currentWarehouseId ?
                            $stockData[ Magestore_Inventorysuccess_Model_Warehouse_Product::TOTAL_QTY ] + $item['qty'] :
                            $stockData[ Magestore_Inventorysuccess_Model_Warehouse_Product::TOTAL_QTY ],
                    );

                    $warehouseData[] = $saveData;
                }
                $product->setWarehouseStock($warehouseData);

                try {
                    Magestore_Coresuccess_Model_Service::productSaveService()
                        ->handleProductSaveAfter($product, array('warehouse_stock' => $warehouseData));

                    $response['items'][$product->getId()] = $stockRegistryService->getStocksByProduct($product->getId());
                } catch (\Exception $exception) {
                    $response['error'] = true;
                    $response['message'] = $exception->getMessage();
                    return $response;
                }

            }
            return $response;
        }

        if ($this->isEnable('Magestore_Inventorywarehouse')) {
            $storeId = Mage::getModel('webpos/userlocation')->load($locationId)
                ->getData('location_store_id');

            $currentWarehouseId = !empty($storeId)
                ? $this->getHelper()->getWarehouseAssociatedStore($storeId)
                : $this->getHelper()->getPrimaryWarehouse()->getId()
            ;
            $warehouse = Mage::getModel('inventoryplus/warehouse')->load($currentWarehouseId);

            foreach ($items as $item) {
                try {
                    /** @var Mage_Catalog_Model_Product $product */
                    $product = Mage::getModel('catalog/product')->load($item['id']);

                    $warehouse->updateStock($item['id'], $item['qty'], $item['qty']);

                    $response['items'][$item['id']] = $this->getHelper()
                        ->getAvailQtyinWarehouseBySku($product->getSku(), $currentWarehouseId);
                } catch (\Exception $exception) {
                    $response['error'] = true;
                    $response['message'] = $exception->getMessage();
                    return $response;
                }

            }
            return $response;
        }


        foreach ($items as $item) {
            /** @var Mage_Catalog_Model_Product $product */
            $product = Mage::getModel('catalog/product')->load($item['id']);
            /** @var Mage_CatalogInventory_Model_Stock_Item $stockItem */
            $stockItem = Mage::getModel('cataloginventory/stock_item')->loadByProduct($product);
            $stockItem->subtractQty($item['qty']);

            try {

                $stockItem->save();

                $response['items'][$product->getId()] = $stockItem->getData();
            } catch (\Exception $exception) {
                $response['error'] = true;
                $response['message'] = $exception->getMessage();
            }


        }

        return $response;
    }

    /**
     * @return Magestore_Inventorywarehouse_Helper_Warehouse
     */
    public function getHelper()
    {
        return $this->_helper; // TODO: Change the autogenerated stub
    }

    /**
     * @param string $module
     * @return bool
     */
    public function isEnable($module){
        $moduleEnable = Mage::helper('core')->isModuleEnabled($module);
        return ($moduleEnable)?true:false;
    }
}
