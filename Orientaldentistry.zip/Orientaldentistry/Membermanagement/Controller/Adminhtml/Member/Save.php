<?php

namespace Orientaldentistry\Membermanagement\Controller\Adminhtml\Member;


class Save extends \Orientaldentistry\Membermanagement\Controller\Adminhtml\Member\AbstractMember
{

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $modelId = (int)$this->getRequest()->getParam('member_id');
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            return $resultRedirect->setPath('*/*/');
        }
        if ($modelId) {
            $model = $this->_objectManager->create('Orientaldentistry\Membermanagement\Model\Member\Member')
                ->load($modelId);
        } else {
            $model = $this->_objectManager->create('Orientaldentistry\Membermanagement\Model\Member\Member');
        }
        $model->setData($data);

        try {
            $model->save();
            $this->messageManager->addSuccess(__('Member was successfully saved'));
        }catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
            return  $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        if ($this->getRequest()->getParam('back') == 'edit') {
            return  $resultRedirect->setPath('*/*/edit', ['id' =>$model->getId()]);
        }
        return $resultRedirect->setPath('*/*/');
    }


}
