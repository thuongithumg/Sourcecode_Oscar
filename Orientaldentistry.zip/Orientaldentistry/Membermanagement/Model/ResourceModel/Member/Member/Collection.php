<?php

namespace Orientaldentistry\Membermanagement\Model\ResourceModel\Member\Member;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     *
     * @var string
     */
    protected $_idFieldName = 'id';
    /**
     * Initialize collection resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Orientaldentistry\Membermanagement\Model\Member\Member',
            'Orientaldentistry\Membermanagement\Model\ResourceModel\Member\Member');
    }

    /**
     *
     * @return array
     */
    public function toOptionArray()
    {
        return parent::_toOptionArray('id','name');
    }

    /**
     * @param array|string $field
     * @param null $condition
     * @return $this
     */
    public function addFieldToFilter($field, $condition = null)
    {
        if ($field == 'id') {
            $field = 'main_table.id';
        }
        return parent::addFieldToFilter($field, $condition);
    }
}
