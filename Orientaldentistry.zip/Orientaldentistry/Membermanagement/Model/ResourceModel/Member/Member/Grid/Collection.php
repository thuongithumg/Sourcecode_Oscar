<?php

namespace Orientaldentistry\Membermanagement\Model\ResourceModel\Member\Member\Grid;

use Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult;

class Collection extends SearchResult
{

}
