<?php

namespace Orientaldentistry\Membermanagement\Block\Adminhtml\Member\Edit;

/**
 * Class Tabs
 * @package Orientaldentistry\Membermanagement\Block\Adminhtml\Member\Edit
 */
class Tabs extends \Magento\Backend\Block\Widget\Tabs
{

    /**
     *
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('member_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Member Information'));
    }

    /**
     * @return $this
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _beforeToHtml()
    {
        $this->addTab(
            'member_form',
            [
                'label' => __('General Information'),
                'title' => __('General Information'),
                'content' => $this->getLayout()->createBlock('Orientaldentistry\Membermanagement\Block\Adminhtml\Member\Edit\Tab\Form')
                    ->toHtml(),
                'active' => true
            ]
        );
        return parent::_beforeToHtml();
    }

}