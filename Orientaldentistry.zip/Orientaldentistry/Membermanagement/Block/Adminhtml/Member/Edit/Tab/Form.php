<?php

namespace Orientaldentistry\Membermanagement\Block\Adminhtml\Member\Edit\Tab;

/**
 * Class Form
 * @package Orientaldentistry\Membermanagement\Block\Adminhtml\Member\Edit\Tab
 */
class Form extends \Magento\Backend\Block\Widget\Form\Generic
    implements \Magento\Backend\Block\Widget\Tab\TabInterface
{

    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $_eventManager;

    /**
     * @var \Orientaldentistry\Membermanagement\Helper\Data
     */
    protected $helper;

    /**
     * Form constructor.
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Orientaldentistry\Membermanagement\Helper\Data $helper
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Orientaldentistry\Membermanagement\Helper\Data $helper,
        array $data = array()
    ) {
        $this->helper = $helper;
        $this->_objectManager = $objectManager;
        $this->_eventManager = $context->getEventManager();
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareLayout() {
        $this->getLayout()->getBlock('page.title')->setPageTitle($this->getPageTitle());
    }

    /**
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _prepareForm()
    {

        $model = $this->_coreRegistry->registry('current_member');

        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('page_');
        $fieldset = $form->addFieldset('base_fieldset', array('legend' => __('Member Information')));

        if ($model->getData('id')) {
            $fieldset->addField('id', 'hidden', array('name' => 'id'));
        }

        $fieldset->addField('name', 'text', array(
            'label'     => __('Member'),
            'class'     => 'required-entry',
            'required'  => true,
            'name'      => 'name',
            'disabled' => false,
        ));
        $fieldset->addField('doctor', 'text', array(
            'label'     => __('Doctor'),
            'class'     => 'required-entry',
            'required'  => true,
            'name'      => 'doctor',
            'disabled' => false,
        ));
        $fieldset->addField('clinic', 'text', array(
            'label'     => __('Clinic'),
            'class'     => 'required-entry',
            'required'  => true,
            'name'      => 'clinic',
            'disabled' => false,
        ));
        $fieldset->addField('nocard', 'text', array(
            'label'     => __('No Card'),
            'class'     => 'required-entry',
            'required'  => true,
            'name'      => 'nocard',
            'disabled' => false,
        ));

        $fieldset->addField(
            'status',
            'select',
            [
                'label' => __('Status'),
                'title' => __('Status'),
                'name' => 'status',
                'required' => true,
                'options' => ['1' => __('Enabled'), '2' => __('Disabled')]
            ]
        );

        $form->setValues($model->getData());
        $this->setForm($form);
        return parent::_prepareForm();
    }

    /**
     * @return mixed
     */
    public function getCurrentModel() {
        return $this->_coreRegistry->registry('current_member');
    }

    /**
     * @return \Magento\Framework\Phrase
     */
    public function getPageTitle() {
        return $this->getCurrentModel()->getId() ? __("Edit Member %1",
            $this->escapeHtml($this->getCurrentModel()->getData('name'))) : __('New Member');
    }

    /**
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Member Information');
    }


    /**
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Member Information');
    }

    /**
     * @return bool
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * @return bool
     */
    public function isHidden()
    {
        return false;
    }


}