<?php

namespace Orientaldentistry\Membermanagement\Ui\Component\Listing\Column;

use Magento\Framework\Data\OptionSourceInterface;

class Member implements OptionSourceInterface
{

    /**
     * @var \Orientaldentistry\Membermanagement\Model\ResourceModel\Member\Member\Collection
     */
    protected $_memberCollection;

    /**
     * Construct
     *
     * @param \Orientaldentistry\Membermanagement\Model\ResourceModel\Member\Member\Collection $memberCollection
     */
    public function __construct(
        \Orientaldentistry\Membermanagement\Model\ResourceModel\Member\Member\Collection $memberCollection
    ) {
        $this->_memberCollection = $memberCollection;
    }

    /**
     * Get product type labels array
     *
     * @return array
     */
    public function getOptionArray()
    {
        $options = [];
        $members = $this->_memberCollection->loadData();
        if (count($members) > 0) {
            foreach ($members as $member) {
                $options[$member->getId()] = (string) $member->getName();
            }
        }
        return $options;
    }

    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        return $this->getOptions();
    }

    /**
     * Get product type labels array for option element
     *
     * @return array
     */
    public function getOptions()
    {
        $res = [];
        foreach ($this->getOptionArray() as $index => $value) {
            $res[] = ['value' => $index, 'label' => $value];
        }
        return $res;
    }

}
